package com.cg.banking.beans;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@SequenceGenerator(name="seqCustomer")
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="seqCustomer")
	private long customerId;
	private String customerName;
	private String emailId;
	private String address;
	private String pancard;
	@Embedded
	private User user;
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Account> accounts;
	public Customer() {
		super();
	}
	public Customer(String customerName, String emailId, String address,
			String pancard, User user, List<Account> accounts) {
		super();
		this.customerName = customerName;
		this.emailId = emailId;
		this.address = address;
		this.pancard = pancard;
		this.user = user;
		this.accounts = accounts;
	}
	public Customer(String customerName, String emailId, String address,
			String pancard, User user) {
		super();
		this.customerName = customerName;
		this.emailId = emailId;
		this.address = address;
		this.pancard = pancard;
		this.user = user;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName="
				+ customerName + ", emailId=" + emailId + ", address="
				+ address + ", pancard=" + pancard + ", user=" + user
				+ ", accounts=" + accounts + "]";
	}
}